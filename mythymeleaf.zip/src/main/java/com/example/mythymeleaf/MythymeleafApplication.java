package com.example.mythymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MythymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(MythymeleafApplication.class, args);
	}

}
