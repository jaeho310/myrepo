package com.example.mythymeleaf.repository;

import java.util.List;

import com.example.mythymeleaf.model.Board;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BoardRepository extends JpaRepository<Board, Long>{
    
    List<Board> findByTitle(String title);
    List<Board> findByTitleOrContent(String title, String content);

    // like처럼 검색 가능
    Page<Board> findByTitleContainingOrContentContaining(String title, String content, Pageable pageable);
}
