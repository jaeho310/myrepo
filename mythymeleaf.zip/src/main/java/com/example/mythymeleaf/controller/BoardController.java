package com.example.mythymeleaf.controller;

import javax.validation.Valid;

import com.example.mythymeleaf.model.Board;
import com.example.mythymeleaf.repository.BoardRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/board")
public class BoardController {
    
    @Autowired
    private BoardRepository boardRepository;

    @GetMapping("/list")
    public String list(Model model, @PageableDefault(size = 5) Pageable pageable, @RequestParam(required = false, defaultValue = "", value = "searchText") String searchText) {
        // Page<Board> boards = boardRepository.findAll(pageable); // board/list?page=0&size=5 이런식으로 넘겨주면 알아서 처리된다.
        
        // Page<Board> boards = boardRepository.findAll(PageRequest.of(0, 20)); // 이런식으로 쓰기보다는 pageable이라는 파라미터를 사용한다.
        // boards.getTotalElements(); thymeleaf에서는 boards.totalElement로 사용
        
        Page<Board> boards = boardRepository.findByTitleContainingOrContentContaining(searchText, searchText, pageable);
        int startPage = Math.max(1,boards.getPageable().getPageNumber() - 4);
        int endPage = Math.min(boards.getTotalPages(), boards.getPageable().getPageNumber() + 4);
        model.addAttribute("startPage", startPage);
        model.addAttribute("endPage", endPage);
        model.addAttribute("boards", boards);
        return "board/list";
    }

    @GetMapping("/form")
    public String form(Model model, @RequestParam(required = false) Long id) {
        if (id == null) {
            model.addAttribute("board", new Board());
        } else {
            Board board = boardRepository.findById(id).orElse(null);
            model.addAttribute("board", board);
        }
        return "board/form";
    }

    @PostMapping("/form")
    // public String formSubmit(@ModelAttribute Board board) {
    public String formSubmit(@Valid Board board, BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            return "board/form";
        }
        boardRepository.save(board);
        // 동일한 키가 있을경우 update 없을경우 save가 된다.
        return "redirect:/board/list";
    }
}
