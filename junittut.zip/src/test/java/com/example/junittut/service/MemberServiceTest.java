package com.example.junittut.service;

import com.example.junittut.model.Member;
import com.example.junittut.repository.MemberMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

class MemberServiceTest {

    MemberService memberService;

    @Mock
    MemberMapper memberMapper;

    @BeforeEach
    void setup() {
        MockitoAnnotations.initMocks(this);
        memberService = new MemberService(memberMapper);
    }

    @Test
    @DisplayName("멤버 상세조회")
    void detail() {
        int memberId = 1;
        String memberName = "Tom";

        Member mockMember = Member.builder().id(memberId).name(memberName).build();

        given(memberMapper.selectById(memberId)).willReturn(mockMember);

        Member responseMember = memberService.detail(memberId);

        assertThat(responseMember.getName()).isEqualTo(memberName);
    }

    @Test
    @DisplayName("멤버 생성")
    void insert() {
        int memberId = 1;
        String memberName = "Tom";

        Member mockMember = Member.builder().id(memberId).name(memberName).build();

        memberService.insert(mockMember);

        verify(memberMapper).insertMember(mockMember);

    }


}