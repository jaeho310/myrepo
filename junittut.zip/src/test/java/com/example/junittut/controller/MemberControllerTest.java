package com.example.junittut.controller;

import com.example.junittut.model.Member;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class MemberControllerTest {

    @Autowired
    MemberController memberController;

    @Autowired
    MockMvc mvc;

//    @Test
//    @Transactional
//    @DisplayName("저장, 전체조회하여 데이터가 잘 들어갔는지 확인")
    void test() throws Exception {
        // 1. James라는 멤버를 Post요청하여 저장합니다.
        Member newMember = Member.builder().name("James").build();
        String jsonData = new Gson().toJson(newMember);

        mvc.perform(post("/api/member")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonData))
                .andExpect(status().isCreated()); // 아래에서 바로 조회까지 할테니 상태코드정도만 확인해줍니다.

        // 저장된 데이터를 단건으로 조회해도 상관없지만
        // 전체조회 로직을 테스트하기 위해 전체를 조회하여 데이터가 있는지 확인해보았습니다.

        MvcResult mvcResult = mvc.perform(get("/api/member"))
                .andExpect(status().isOk())
                .andDo(print())
                .andReturn();

        String jsonResult = mvcResult.getResponse().getContentAsString();

        JsonParser jsonParser = new JsonParser();
        JsonArray jsonArray = jsonParser.parse(jsonResult).getAsJsonArray();
        Gson gson = new Gson();
        boolean isContainJames = false;
        for (JsonElement jsonElement : jsonArray) {
            Member member = gson.fromJson(jsonElement, Member.class);
            if ("James".equals(member.getName())){
                isContainJames = true;
                break;
            }
        }
        assertThat(isContainJames).isTrue();
    }

//    @Test
//    @Transactional
//    @DisplayName("삭제, 전체데이터갯수 변화 확인")
    void test2() throws Exception {

        // 전체조회하여 첫번째 데이터를 꺼내옵니다.
        MvcResult mvcResult1 = mvc.perform(get("/api/member"))
                .andExpect(status().isOk())
                .andDo(print())
                .andReturn();

        String jsonResult = mvcResult1.getResponse().getContentAsString();

        JsonParser jsonParser = new JsonParser();
        JsonArray jsonArray = jsonParser.parse(jsonResult).getAsJsonArray();

        int id = jsonArray.get(0).getAsJsonObject().get("id").getAsInt();
        int size = jsonArray.size();

        // 첫번째 데이터를 삭제합니다.
        mvc.perform(delete("/api/member/"+id))
                .andExpect(status().isOk());

        MvcResult mvcResult2 = mvc.perform(get("/api/member"))
                .andExpect(status().isOk())
                .andDo(print())
                .andReturn();

        String jsonResult2 = mvcResult2.getResponse().getContentAsString();

        // 전체 데이터갯수가 한개 줄었나 확인해줍니다.
        assertThat(jsonParser.parse(jsonResult2).getAsJsonArray().size()).isEqualTo(size-1);

    }

//    @Test
//    @DisplayName("조회, 업데이트, 단건조회 테스트")
//    @Transactional
    void test3() throws Exception {
        // 전체조회하여 첫번째 데이터를 업데이트해줍니다.
        MvcResult mvcResult1 = mvc.perform(get("/api/member"))
                .andExpect(status().isOk())
                .andDo(print())
                .andReturn();

        String jsonResult = mvcResult1.getResponse().getContentAsString();

        JsonParser jsonParser = new JsonParser();
        JsonArray jsonArray = jsonParser.parse(jsonResult).getAsJsonArray();

        String id = jsonArray.get(0).getAsJsonObject().get("id").getAsString();


        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        String newName = "Jake";
        params.add("name", newName);
        params.add("id",id);
        mvc.perform(patch("/api/member")
                .params(params))
                .andExpect(status().isOk());


        MvcResult mvcResult2 = mvc.perform(get("/api/member/" + id))
                .andExpect(status().isOk())
                .andReturn();

        String response = mvcResult2.getResponse().getContentAsString();

        Gson gson = new Gson();
        Member updatedMember = gson.fromJson(response, Member.class);

        // 업데이트후 조회된 이름과 업데이트하기로한 이름을 비교해줍니다.
        assertThat(updatedMember.getName()).isEqualTo(newName);
    }
}