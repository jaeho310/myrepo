package com.example.junittut.controller;

import com.example.junittut.model.Member;
import com.example.junittut.service.MemberService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class MemberController {

    MemberService memberService;

    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/member")
    public ResponseEntity<List<Member>> list(){
        List<Member> response = memberService.list();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/member/{id}")
    public ResponseEntity<Member> detail(@PathVariable("id") int id) throws Exception {
        Member member = memberService.detail(id);
        return new ResponseEntity<>(member, HttpStatus.OK);
    }

    @PostMapping("/member")
    public ResponseEntity<?> insert(@RequestBody Member member) throws Exception {
        int response = memberService.insert(member);
        return new ResponseEntity<>(response,HttpStatus.CREATED);
    }

    @PatchMapping("/member")
    public ResponseEntity<?> update(@RequestParam("id") int id, @RequestParam("name") String name) throws Exception {
        Member member = new Member(id,name);
        int response = memberService.update(member);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("/member/{id}")
    public ResponseEntity<?> delete(@PathVariable("id") int id) throws Exception {
        int response = memberService.delete(id);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
