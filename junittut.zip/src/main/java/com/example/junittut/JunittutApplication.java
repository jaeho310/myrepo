package com.example.junittut;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;

import javax.sql.DataSource;

@SpringBootApplication
public class JunittutApplication {

	public static void main(String[] args) {
		SpringApplication.run(JunittutApplication.class, args);
	}
}
