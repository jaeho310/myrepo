package com.example.junittut.repository;

import com.example.junittut.model.Member;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MemberMapper {
    List<Member> selectAllMembers();

    Member selectById(int id);

    int insertMember(Member member);

    int deleteMember(int id);

    int updateMember(Member member);

    int isValidMember(int id);
}
