package com.example.jacocotest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JacocotestApplicationTests {

	@Test
	void contextLoads() {
	}

}
